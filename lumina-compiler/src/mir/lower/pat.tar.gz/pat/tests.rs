use super::{
    BranchOf, DecTree, DecTreeBranch, Expr, Formatter, IsReachable, ListConstr, Merger,
    MissingGeneration, Params, PatPoint, PointToBindTranslationTable, Range, SumInfo, Type,
    REACHABLE, UNREACHABLE,
};
use ibig::IBig;
use itertools::Itertools;
use lumina_key as key;
use lumina_typesystem::Bitsize;
use tracing::info;

// TODO: let's just construct dectrees directly instead. No HIR stuff

struct TestSumInfo {}

impl SumInfo for TestSumInfo {
    fn sum_variants(
        &self,
        sum: key::M<key::Sum>,
    ) -> impl Iterator<Item = key::SumVariant> + 'static {
        match sum.value {
            LIST => [CONS, NIL].into_iter(),
            _ => unreachable!(),
        }
    }

    fn variant_ptypes(
        &self,
        sum: key::M<key::Sum>,
        var: key::SumVariant,
        params: &[lumina_typesystem::Type],
    ) -> Vec<lumina_typesystem::Type> {
        todo!()
    }

    fn params_of(&self, sum: key::M<key::Sum>, var: key::SumVariant) -> usize {
        match sum.value {
            LIST => 2,
            _ => unreachable!(),
        }
    }
}

fn patmerger() -> Merger<TestSumInfo> {
    Merger { get_sum: TestSumInfo {} }
}

const CONS: key::SumVariant = key::SumVariant(0);
const NIL: key::SumVariant = key::SumVariant(1);
const LIST: key::Sum = key::Sum(0);

impl Formatter for TestSumInfo {
    fn name_of_fields(&self, record: key::M<key::Record>) -> impl Iterator<Item = &str> {
        [].into_iter()
    }
    fn name_of_variant(&self, sum: key::M<key::Sum>, var: key::SumVariant) -> String {
        match (sum.value, var) {
            (LIST, CONS) => "cons".into(),
            (LIST, NIL) => "nil".into(),
            _ => panic!("unknown sum variant"),
        }
    }
}

impl MissingGeneration for TestSumInfo {}

macro_rules! tree {
    ($init:expr, $($tree:expr => $reachable:expr),*) => {
        merge_trees([($init, REACHABLE), $(($tree, $reachable)),*])
    };
    (exhaustive ; $init:expr, $($tree:expr => $reachable:expr),*) => {
        let tree = tree!($init, $($tree => $reachable),*);

        let missing = TestSumInfo {}.invert(&tree, 1);
        if let Some(missing) = missing {
            let fmtpatterns = TestSumInfo {}.tree_to_fmt_patterns(&missing);
            panic!("missing patterns:\n  {}", fmtpatterns.iter().format("\n  "));
        }
    };
    (missing: [$($name:literal),*] ; $init:expr, $($tree:expr => $reachable:expr),*) => {
        let tree = tree!($init, $($tree => $reachable),*);
        let missing = TestSumInfo {}.invert(&tree, 1).map(|m| TestSumInfo {}.tree_to_fmt_patterns(&m));

        let expected = [$($name),*];

        let mut ok = false;

        if let Some(missing) = &missing {
            ok = missing.len() == expected.len();

            for m in missing {
                let str = m.to_string();
                if expected.iter().all(|e| str.as_str() != *e) {
                    ok = false;
                }
            }
        }

        if !ok {
            panic!(
               "expected a different set of missing patterns\nexpected:\n  {}\ngot:\n  {}",
               expected.iter().format("\n  "),
               missing.unwrap_or(vec![]).iter().format("\n  "),
            );
        }
    }
}

#[test]
fn int_tuples() {
    tree! { exhaustive ;
        tuple(2, range(0..100, range(0..50, tail(0)))),
        tuple(2, range(0..100, range(50..100, tail(1)))) => REACHABLE,
        tuple(2, range(0..100, range(0..100, tail(2)))) => UNREACHABLE
    };

    tree! {
        missing: ["(.., _)"] ;
        tuple(2, range(0..100, range(1..50, tail(0)))),
        tuple(2, range(0..100, range(50..100, tail(1)))) => REACHABLE,
        tuple(2, range(0..100, range(1..100, tail(2)))) => UNREACHABLE
    };

    tree! {
        missing: ["(_, _)"] ;
        tuple(2, range(4..8, range(50..100, tail(0)))),
        tuple(2, range(4..6, range(0..100, tail(1)))) => REACHABLE,
        tuple(2, range(4..7, range(0..100, tail(2)))) => REACHABLE
    };
}

#[test]
fn lists() {
    tree! { exhaustive ;
        cons(wildcard(wildcard(tail(0)))), // [x : xs]
        nil(tail(1)) => REACHABLE, // []
        wildcard(tail(2)) => UNREACHABLE // _
    };

    tree! { missing: ["[_ : _]"] ;
        cons(wildcard(nil(tail(0)))), // [x]
        nil(tail(1)) => REACHABLE // []
    };
}

#[test]
fn wildcards() {
    tree! { exhaustive ;
        tuple(2, wildcard(wildcard(tail(0)))),
        wildcard(tail(1)) => UNREACHABLE
    };

    tree! { missing: ["(_, _)"] ;
        tuple(2, range(0..50, wildcard(tail(0)))),
    };

    tree! { exhaustive ;
        wildcard(tail(0)),
    };
}

fn dump_patterns(tree: &DecTree) -> impl std::fmt::Display {
    TestSumInfo {}
        .tree_to_fmt_patterns(tree)
        .into_iter()
        .format("\n")
}

#[track_caller]
fn merge_trees<const N: usize>(trees: [(DecTree, IsReachable); N]) -> DecTree {
    let mut iter = trees.into_iter();
    let (mut init, _) = iter.next().unwrap();

    println!("init pattern: {}", dump_patterns(&init));

    let mut merger = patmerger();
    for (tree, reachable) in iter {
        let untouched = init.clone();

        let ok = merger.merge(&mut init, tree.clone()) == reachable;
        println!(
            "\nmerging {} into\n{}\nturned into\n{}\n",
            dump_patterns(&tree),
            dump_patterns(&untouched),
            dump_patterns(&init)
        );

        if !ok {
            let pat = TestSumInfo {}.tree_to_fmt_patterns(&tree).pop().unwrap();

            panic!(
                "{pat} was expected to be {}",
                if reachable {
                    "reachable"
                } else {
                    "unreachable"
                },
            );
        }
    }

    init
}

fn int(n: u8, then: DecTree) -> DecTree {
    range(n..n, then)
}

fn range(r: std::ops::Range<u8>, mut then: DecTree) -> DecTree {
    then.offset_binds(1);
    entry(DecTreeBranch::Ints(
        IBig::from(0),
        IBig::from(100),
        BranchOf::one(
            Range { start: IBig::from(r.start), end: IBig::from(r.end) },
            0,
            then,
        ),
    ))
}

fn wildcard(mut then: DecTree) -> DecTree {
    then.offset_binds(1);
    entry(DecTreeBranch::Wildcard(Box::new(then)))
}

fn tuple(params: Params, mut then: DecTree) -> DecTree {
    then.offset_binds(1);
    entry(DecTreeBranch::Tuple(params, Box::new(then)))
}

fn nil(mut then: DecTree) -> DecTree {
    then.offset_binds(1);
    entry(DecTreeBranch::List(
        key::Module(0).m(key::TypeKind::Sum(LIST)),
        Type::Int(true, Bitsize::default()),
        BranchOf { branches: vec![(ListConstr::Nil, 0, then)] },
    ))
}

fn cons(mut then: DecTree) -> DecTree {
    then.offset_binds(1);
    entry(DecTreeBranch::List(
        key::Module(0).m(key::TypeKind::Sum(LIST)),
        Type::Int(true, Bitsize::default()),
        BranchOf { branches: vec![(ListConstr::Cons, 2, then)] },
    ))
}

fn entry(branch: DecTreeBranch) -> DecTree {
    DecTree { branch, point: PatPoint(0) }
}

fn tail(n: i32) -> DecTree {
    entry(DecTreeBranch::Reached(
        PointToBindTranslationTable { map: vec![] },
        Box::new(Expr::UInt(Bitsize::default(), n as u128)),
    ))
}
