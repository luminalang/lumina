use super::{Expr, FinType, InstInfo, InstSource, Lower, RecordInfo, SumInfo};
use crate::prelude::*;
use derive_new::new;
use ibig::IBig;
use lumina_key::{entity_impl, keys};
use lumina_parser::pat::Bound;
use lumina_typesystem::Type;
use std::fmt;

mod ints;
use ints::Range;

mod missing;
pub use missing::{FmtPattern, Formatter, MissingGeneration};

#[cfg(test)]
mod tests;

#[derive(Clone, Debug)]
pub enum DecTreeBranch {
    // Floats(BranchOf<f64>),
    Ints(IBig, IBig, BranchOf<Range>),
    Tuple(Params, Box<DecTree>),
    Bools(BranchOf<bool>),
    Sum(InstInfo, M<key::Sum>, BranchOf<key::SumVariant>),
    List(M<key::TypeKind>, Type, BranchOf<ListConstr>),
    Record(M<key::Record>, Params, Box<DecTree>),
    Reached(PointToBindTranslationTable, Box<Expr>),
    // Unreached(Type),
    Wildcard(Box<DecTree>),

    Poison,
}
pub type Params = usize;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ListConstr {
    Cons,
    Nil,
}

#[derive(Clone, Debug)]
pub struct DecTree {
    point: PatPoint,
    branch: DecTreeBranch,
}

impl DecTree {
    fn offset_binds(&mut self, by: u32) {
        self.point.0 += by;
        self.branch.offset_binds(by);
    }
}

impl DecTreeBranch {
    fn offset_binds(&mut self, by: u32) {
        match self {
            DecTreeBranch::Bools(branches) => branches.offset_binds(by),
            DecTreeBranch::Ints(_, _, branches) => branches.offset_binds(by),
            DecTreeBranch::Tuple(_, next) => next.offset_binds(by),
            DecTreeBranch::Sum(_, _, branches) => branches.offset_binds(by),
            DecTreeBranch::Record(_, _, next) => next.offset_binds(by),
            DecTreeBranch::Reached(table, _) => table.offset_binds(by),
            DecTreeBranch::Wildcard(next) => next.offset_binds(by),
            DecTreeBranch::List(_, _, branches) => branches.offset_binds(by),
            DecTreeBranch::Poison => {}
        }
    }
}

impl<T> BranchOf<T> {
    fn one(value: T, params: Params, next: DecTree) -> BranchOf<T> {
        BranchOf { branches: vec![(value, params, next)] }
    }

    fn offset_binds(&mut self, by: u32) {
        self.branches
            .iter_mut()
            .for_each(|(_, _, next)| next.offset_binds(by));
    }
}

#[derive(Clone, Default, Debug)]
pub struct PointToBindTranslationTable {
    map: Vec<(key::Bind, PatPoint)>,
}

impl PointToBindTranslationTable {
    fn offset_binds(&mut self, by: u32) {
        self.map.iter_mut().for_each(|(_, p)| p.0 += by)
    }
}

keys!(PatPoint . "point");

impl Default for PatPoint {
    fn default() -> Self {
        PatPoint(0)
    }
}

#[derive(Clone, Debug)]
pub struct BranchOf<T> {
    branches: Vec<(T, Params, DecTree)>,
}

impl<T, I: IntoIterator<Item = (T, Params, DecTree)>> From<I> for BranchOf<T> {
    fn from(value: I) -> Self {
        BranchOf { branches: value.into_iter().collect() }
    }
}

type IsReachable = bool;
const REACHABLE: IsReachable = true;
const UNREACHABLE: IsReachable = false;

impl DecTreeBranch {}

#[derive(new)]
pub struct TreeBuilder<'p, 's, B: Bridge<'p, 's>> {
    #[new(default)]
    point: PatPoint,

    #[new(default)]
    table: PointToBindTranslationTable,

    #[new(default)]
    queue: Vec<(&'p hir::Pattern<'s>, Option<key::Bind>)>,

    bridge: B,

    params: &'p [Tr<hir::Pattern<'s>>],
    expr: Tr<&'p hir::Expr<'s>>,
    #[new(default)]
    current_param: usize,
    ptypes: &'p [Type],
}

pub trait Bridge<'p, 's>: FinType + RecordInfo + SumInfo + InstSource {
    fn lower_tail_expr(&mut self, expr: Tr<&'p hir::Expr<'s>>) -> Expr;
}

fn extend_untr<'a, T>(queue: &mut Vec<(&'a T, Option<key::Bind>)>, extra: &'a [Tr<T>]) {
    extra.iter().rev().for_each(|v| queue.push((v, None)));
}

impl<'p, 's, B: Bridge<'p, 's>> TreeBuilder<'p, 's, B> {
    pub fn parameters_to_tree(
        bridge: B,
        params: &'p [Tr<hir::Pattern<'s>>],
        expr: Tr<&'p hir::Expr<'s>>,
        ptypes: &'p [Type],
    ) -> Expr {
        let this = Self::new(bridge, params, expr, ptypes);
        this.lower_tail()
    }

    pub fn new_tree(mut self, pat: &'p hir::Pattern<'s>) -> DecTree {
        let point = self.point;
        self.point.0 += 1;

        let branch = match pat {
            hir::Pattern::Any => DecTreeBranch::Wildcard(Box::new(self.from_queue())),
            hir::Pattern::Int([start, end], var) => match self.bridge.fin_int(*var) {
                None => DecTreeBranch::Poison,
                Some((signed, bitsize)) => {
                    let max = IBig::from(bitsize.maxi(signed));
                    let min = signed
                        .then(|| -max.clone())
                        .unwrap_or_else(|| IBig::from(0));

                    let range = Range {
                        start: bound_to_ibig(*start, &min),
                        end: bound_to_ibig(*end, &max),
                    };

                    DecTreeBranch::Ints(min, max, BranchOf::one(range, 0, self.from_queue()))
                }
            },
            hir::Pattern::Bind(bind, next) => {
                self.table.map.push((*bind, point));
                self.point.0 -= 1; // binding doesn't produce a new point
                self.new_tree(&next).branch
            }
            hir::Pattern::Constructor(sum, variant, params) => {
                extend_untr(&mut self.queue, params);
                let instinfo = self.bridge.pop_inst();
                let next = self.from_queue();
                DecTreeBranch::Sum(instinfo, *sum, BranchOf::one(*variant, params.len(), next))
            }
            hir::Pattern::Record(rvar, _, fields) => match self.bridge.fin_record(*rvar) {
                None => DecTreeBranch::Poison,
                Some((key, _)) => {
                    let mut count = 0;

                    self.bridge.record_fields(key).rev().for_each(|field| {
                        let name = self.bridge.name_of_field(key, field);
                        count += 1;

                        match fields.iter().find(|(n, _, _)| *n == name) {
                            None => {
                                warn!("allowing missing field in record pattern: {name}");
                                self.queue.push((&hir::Pattern::Any, None));
                            }
                            Some((_, bind, pat)) => {
                                self.queue.push((&**pat, Some(*bind)));
                            }
                        }
                    });

                    DecTreeBranch::Record(key, count, Box::new(self.from_queue()))
                }
            },
            hir::Pattern::Tuple(elems) => {
                extend_untr(&mut self.queue, elems);
                DecTreeBranch::Tuple(elems.len(), Box::new(self.from_queue()))
            }
            hir::Pattern::Cons(elems, lvar, var) => {
                let type_ = self.bridge.fin_list(*lvar).unwrap();
                let inner = self.bridge.fin_var(*var);

                let list_type = Type::Defined(type_, vec![inner.clone()]);

                let [x, xs] = &**elems;

                self.queue.push((x, None));
                self.queue.push((xs, None));

                DecTreeBranch::List(
                    type_,
                    list_type,
                    BranchOf { branches: vec![(ListConstr::Cons, 2, self.from_queue())] },
                )
            }
            hir::Pattern::Nil(lvar, var) => {
                let type_ = self.bridge.fin_list(*lvar).unwrap();
                let inner = self.bridge.fin_var(*var);

                let list_type = Type::Defined(type_, vec![inner.clone()]);

                DecTreeBranch::List(
                    type_,
                    list_type,
                    BranchOf { branches: vec![(ListConstr::Nil, 0, self.from_queue())] },
                )
            }
            hir::Pattern::Bool(b) => DecTreeBranch::Bools(BranchOf::one(*b, 0, self.from_queue())),
            hir::Pattern::String(str) => todo!("string patterns"),
            hir::Pattern::Poison => todo!("how can there be poison but no error??"),
        };

        DecTree { point, branch }
    }

    fn from_queue(mut self) -> DecTree {
        match self.queue.pop() {
            Some((p, bind)) => {
                if let Some(bind) = bind {
                    self.table.map.push((bind, self.point));
                };
                self.new_tree(p)
            }
            None => {
                let point = std::mem::take(&mut self.point);
                let table = std::mem::take(&mut self.table);
                let tail = self.lower_tail();
                let branch = DecTreeBranch::Reached(table, Box::new(tail));
                DecTree { branch, point }
            }
        }
    }

    fn lower_tail(mut self) -> Expr {
        match self.params.get(self.current_param) {
            None => self.bridge.lower_tail_expr(self.expr),
            Some(pat) => {
                let param = key::Param(self.current_param as u32);
                let ty = self.ptypes[self.current_param].clone();
                self.current_param += 1;

                let dec = self.new_tree(pat);

                let on = Expr::Yield(mir::func::Local::Param(param), ty);
                Expr::Match(Box::new(on), dec)
            }
        }
    }
}

#[derive(new)]
pub struct Merger<Sum> {
    get_sum: Sum,
}

impl<Sum: SumInfo> Merger<Sum> {
    pub fn merge(&mut self, tree: &mut DecTree, other: DecTree) -> IsReachable {
        use DecTreeBranch as B;

        match (&mut tree.branch, other.branch) {
            (B::Ints(min, max, ranges), B::Ints(omin, omax, oranges)) => {
                assert_eq!(*min, omin);
                assert_eq!(*max, omax);
                assert_eq!(tree.point, other.point);
                oranges
                    .branches
                    .into_iter()
                    .any(|(o, _, next)| self.merge_int(0, ranges, o, next))
            }
            (B::Tuple(params, next), B::Tuple(oparams, onext)) => {
                assert_eq!(tree.point, other.point);
                assert_eq!(*params, oparams);
                self.merge(&mut *next, *onext)
            }
            (B::Record(key, _, fields), B::Record(okey, _, ofields)) => {
                assert_eq!(tree.point, other.point);
                assert_eq!(*key, okey);
                self.merge(&mut *fields, *ofields)
            }
            (B::Poison, _) | (_, B::Poison) => true,
            (B::Bools(bools), B::Bools(obools)) => {
                assert_eq!(tree.point, other.point);
                self.merge_cmps(bools, obools)
            }
            (B::Sum(_, key, variants), B::Sum(_, okey, ovariants)) => {
                assert_eq!(*key, okey);
                self.merge_cmps(variants, ovariants)
            }
            (B::Reached(..), B::Reached(..)) => UNREACHABLE,
            (B::Wildcard(next), B::Wildcard(onext)) => self.merge(next, *onext),

            (B::List(key, _, variants), B::List(okey, _, ovariants)) => {
                assert_eq!(*key, okey);
                self.merge_cmps(variants, ovariants)
            }

            (B::Wildcard(next), other) => {
                // swap the positions so that the more specialised tree becomes the existing one
                //
                // then merge the previous wildcard into that specialised tree
                //
                // then swap the references so that the specialised tree is put into `tree`
                let mut other = DecTree { point: tree.point, branch: other };
                let tnext = std::mem::replace(&mut next.branch, DecTreeBranch::Poison);
                let reachable =
                    self.merge_wildcard(&mut other, DecTree { point: next.point, branch: tnext });
                std::mem::swap(tree, &mut other);
                reachable
            }
            (_, B::Wildcard(next)) => self.merge_wildcard(tree, *next),

            _ => {
                error!("invalid pattern tree combination");

                #[cfg(test)]
                panic!("invalid pattern tree combination");

                REACHABLE
            }
        }
    }

    fn merge_cmps<T: PartialEq>(
        &mut self,
        bools: &mut BranchOf<T>,
        other: BranchOf<T>,
    ) -> IsReachable {
        other.branches.into_iter().any(|(o, params, onext)| {
            match bools.branches.iter_mut().find(|(b, _, _)| *b == o) {
                Some((_, _, next)) => self.merge(next, onext),
                None => {
                    bools.branches.push((o, params, onext));
                    REACHABLE
                }
            }
        })
    }

    fn merge_wildcard(&mut self, tree: &mut DecTree, wnext: DecTree) -> IsReachable {
        let faked = match &mut tree.branch {
            DecTreeBranch::Ints(min, max, _) => DecTreeBranch::Ints(
                min.clone(),
                max.clone(),
                BranchOf {
                    branches: vec![(Range { start: min.clone(), end: max.clone() }, 0, wnext)],
                },
            ),
            DecTreeBranch::List(key, inner, _) => DecTreeBranch::List(
                *key,
                inner.clone(),
                BranchOf {
                    branches: vec![
                        (
                            ListConstr::Cons,
                            2,
                            wildcard_chain(PatPoint(tree.point.0 + 1), 2, wnext.clone()),
                        ),
                        (ListConstr::Nil, 0, wnext),
                    ],
                },
            ),
            DecTreeBranch::Tuple(params, _) => {
                let wildcards = wildcard_chain(PatPoint(tree.point.0 + 1), *params, wnext);
                DecTreeBranch::Tuple(*params, Box::new(wildcards))
            }
            DecTreeBranch::Bools(_) => DecTreeBranch::Bools(BranchOf {
                branches: vec![(false, 0, wnext.clone()), (true, 0, wnext)],
            }),
            DecTreeBranch::Sum(inst, key, _) => DecTreeBranch::Sum(
                inst.clone(),
                *key,
                BranchOf {
                    branches: self
                        .get_sum
                        .sum_variants(*key)
                        .map(|var| {
                            let params = self.get_sum.params_of(*key, var);
                            let wnext =
                                wildcard_chain(PatPoint(tree.point.0 + 1), params, wnext.clone());
                            (var, params, wnext)
                        })
                        .collect(),
                },
            ),
            DecTreeBranch::Record(key, params, _) => {
                let wnext = wildcard_chain(PatPoint(tree.point.0 + 1), *params, wnext);
                DecTreeBranch::Record(*key, *params, Box::new(wnext))
            }
            DecTreeBranch::Reached(_, _) => panic!("corrupt pattern tree"),
            DecTreeBranch::Wildcard(next) => return self.merge(next, wnext),
            DecTreeBranch::Poison => return UNREACHABLE,
        };

        self.merge(tree, DecTree { point: tree.point, branch: faked })
    }
}

fn wildcard_chain(point: PatPoint, params: Params, mut wnext: DecTree) -> DecTree {
    wnext.offset_binds(params as u32);

    fn perform(point: PatPoint, params: Params, wnext: DecTree) -> DecTree {
        if params == 0 {
            wnext
        } else {
            DecTree {
                point,
                branch: DecTreeBranch::Wildcard(Box::new(wildcard_chain(
                    PatPoint(point.0 + 1),
                    params - 1,
                    wnext,
                ))),
            }
        }
    }

    perform(point, params, wnext)
}

fn bound_to_ibig(bound: Bound, excess: &IBig) -> IBig {
    match bound {
        Bound::Neg(n) => -IBig::from(n),
        Bound::Pos(n) => IBig::from(n),
        Bound::Excess => excess.clone(),
    }
}

impl<'p, 'l, 'a, 's> Bridge<'p, 's> for &mut Lower<'l, 'a, 's> {
    fn lower_tail_expr(&mut self, expr: Tr<&'p hir::Expr<'s>>) -> Expr {
        self.lower_expr(expr)
    }
}
